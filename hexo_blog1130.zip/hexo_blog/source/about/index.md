---
title: 关于我
date: 2018-07-02 20:28:43
---


<div style="text-align: center">
I was a man in a hurry, 

from small to large, 

have some more powerful than others! 

There does not appear to be any decent.

Was being prompt whim this site to do, 

hope that one day can see oneself once leave things as a souvenir!



If you can help me, I will thank you again!
</div>