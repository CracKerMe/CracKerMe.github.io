---
title: webstorm 破解
date: 2018-09-18 00:43:22
tags: 分享
---

#### 该破解方法 来源于互联网，有经济实力的 请支持正版。

##### 请低调使用！！！

**webstorm mac 2018**是由JetBrains公司研发并推出的一款mac版web前端开发工具，它不仅拥有智能代码补全、代码格式化、html提示、联想查询、代码重构、代码调试、代码折叠等实用型功能，其针对Java9带来的新版模块系统也提供了完善的底层支持，在使用node.js开发服务端的基础上，帮助您更好的进行前端页面开发的代码编辑形式，既包含了大量功能的改进，同时在Angular语言服务的支持上也极大的提升了用户在web前端开发过程中的研发体验。

<!--more-->

WebStorm 2018.2之后的版本 校验方式发生了更改，之前的`license server` 均不可使用，加之这段时间 **jetbrains** 对于违规的 `license server`服务器的清理，导致大批 人的盗版webstorm 被打回原形。



## 激活方式

1. 下载 [jar 的破解java包](http://awebman.top/JetbrainsCrack.jar) (Mac 、windows 通用)，彻底退出 webstorm

2. 拷贝jar 文件至 webstorm 的 安装目录的 **/bin/** 目录下(Mac 和 windows路径如下)

3. 修改配置文件 完成 破解包的配置

   #### Mac用户: 

    1. 打开 访达/应用程序/WebStorm-右击,显示包内容-Contents/bin/**webstorm.vmoptions**

       最后一行添加代码为(.jar的绝对路径)

       ```shell
       -javaagent:/Applications/Webstorm.app/Contents/bin/JetbrainsCrack.jar
       ```

    2. Save

   #### Windows用户:

   以 **WebStorm-2018.2.exe** 64位安装文件为例，

   1. 打开编辑 `C:\Program Files\JetBrains\WebStorm 2018.2\bin\` 目录下的__webstorm.exe.vmoptions__和__webstorm64.exee.vmoptions__ 两个文件

      分别在末尾添加(.jar的绝对路径)

      ```shell
      -javaagent:C:\Program Files\JetBrains\WebStorm 2018.2\bin\JetbrainsCrack.jar
      ```

   2. Save

4. 重新打开 webstorm，在 License Activation 选择__Activation code__，任意输入 都可以成功激活

5. Congratulations!!!



__Yours Sincerely AppleSun__