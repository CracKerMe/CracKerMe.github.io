---
title: 如何在vue中使用vw移动端适配
date: 2018-07-02 13:56:21
tags:
- 移动端
---

转载修改自大漠的 vw适配方案。vue 项目中使用vw 做移动端适配

<!--more-->



```shell
npm i postcss-aspect-ratio-mini postcss-px-to-viewport postcss-write-svg postcss-cssnext postcss-viewport-units cssnano -S

npm i cssnano-preset-advanced --save-dev
```

接下来对 `.postcssrc.js` 做出配置:

```javascript
// https://github.com/michael-ciniawsky/postcss-load-config

module.exports = {
  plugins: {
    'postcss-import': {},
    'postcss-url': {},
    'postcss-aspect-ratio-mini': {},
    // to edit target browsers: use "browserslist" field in package.json
    autoprefixer: {}, //被cssnext和 cssnano 所带的 autoprefixer 干掉了
    "postcss-write-svg": {
      utf8: false
    },
    'postcss-cssnext': {},
    'postcss-px-to-viewport': {
      viewportWidth: 750, // 视窗的宽度，对应的是我们设计稿的宽度，一般是750
      viewportHeight: 1334, // 视窗的高度，根据750设备的宽度来指定，一般指定1334，也可以不配置
      unitPrecision: 3, // 指定`px`转换为视窗单位值的小数位数（很多时候无法整除）
      viewportUnit: 'vw', // 指定需要转换成的视窗单位，建议使用vw
      selectorBlackList: ['.ignore', '.hairlines'], // 指定不转换为视窗单位的类，可以自定义，可以无限添加,建议定义一至两个通用的类名
      minPixelValue: 1, // 小于或等于`1px`不转换为视窗单位，你也可以设置为你想要的值
      mediaQuery: false // 允许在媒体查询中转换`px`
    },
    'postcss-viewport-units': {},
    cssnano: {
      preset: 'advanced',
      autoprefixer: false,
      'postcss-zindex': false
    }
  }
}

```

在不想要把`px`转换为`vw`的时候，首先在对应的元素（`html`）中添加配置中指定的类名`.ignore`或`.hairlines`(`.hairlines`一般用于设置`border-width:0.5px`的元素中)



在哪些地方可以使用`vw`来适配我们的页面。根据相关的测试：

- 容器适配，可以使用`vw`
- 文本的适配，可以使用`vw`
- 大于`1px`的边框、圆角、阴影都可以使用`vw`
- 内距和外距，可以使用`vw



如果我们想要做一个`188:246`（`188`是容器宽度，`246`是容器高度）这样的比例容器，只需要这样使用：

```scss
[w-188-246] {
    aspect-ratio: '188:246';
}
```

有一点需要特别注意：aspect-ratio属性不能和其他属性写在一起，否则编译出来的属性只会留下aspect-ratio的值







__border-image__ 方式  处理底框1px：

```scss
@svg 1px-border {
	height: 2px;
	@rect {
		fill: var(--color, black);
		width: 100%;
		height: 50%;
	}
}
.example {
	border: 1px solid transparent;
	border-image: svg(1px-border param(--color #00b1ff)) 2 2 stretch;
}
```

__background-iamge__方式来处理1px:

```scss
@svg square {
	@rect {
		fill: var(--color, black);
		width: 100%;
		height: 100%;
	}
}
#example {
	background: white svg(square param(--color #00b1ff));
}
```



CDN

`viewport-units-buggyfill`主要有两个JavaScript文件：`viewport-units-buggyfill.js`和`viewport-units-buggyfill.hacks.js`。你只需要在你的HTML文件中引入这两个文件。比如在Vue项目中的`index.html`引入它们

```html
<script src="//g.alicdn.com/fdilab/lib3rd/viewport-units-buggyfill/0.6.2/??viewport-units-buggyfill.hacks.min.js,viewport-units-buggyfill.min.js"></script>
```

第二步，在HTML文件中调用`viewport-units-buggyfill`，比如：

```html
<script>
    window.onload = function () {
        window.viewportUnitsBuggyfill.init({
            hacks: window.viewportUnitsBuggyfillHacks
        });
    }
</script>
```

只要使用到了`viewport`的单位（`vw`、`vh`、`vmin`或`vmax` ）地方，需要在样式中添加`content`



但是`content`也会引起一定的副作用。比如`img`和伪元素`::before`(`:before`)或`::after`（`:after`）。在`img`中`content`会引起部分浏览器下，图片不会显示。这个时候需要全局添加：

```scss
img {
    content: normal !important;
}
```

