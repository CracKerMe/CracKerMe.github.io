---
title: vue 生命周期理解
date: 2018-07-10 00:06:40
tags: vue
---

#### 请详细说下你对vue生命周期的理解？
总共分为8个阶段创建前/后，载入前/后，更新前/后，销毁前/后

<!--more-->

![Vue 生命周期图](http://image.awebman.cn/pic2018072201.png)

先贴上一张图



为什么 我会好端端的 谈起这个生命周期呢，唉



#### Vue生命周期勾子函数

对比1.0 的文档，生命周期 的变化如下:

| Vue 1.0       | Vue 2.0       | Description                                          |
| ------------- | ------------- | ---------------------------------------------------- |
| init          | beforeCreate  | 组件实例被创建，组件属性计算之前，如data 属性        |
| created       | created       | 组件实例创建完成，属性已绑定，dom没生成，$el还不存在 |
| beforeCompile | beforeMount   | 模板编译、挂载之前                                   |
| compiled      | mounted       | 模板编译、挂载好                                     |
| ready         | mounted       | 模板编译、挂载好(不保证组件已在document中)           |
| -             | beforeUpdate  | 组件更新之前                                         |
| -             | updated       | 组件更新之后                                         |
| -             | activated     | for `keep-alive` ,组件被激活的时候调用               |
| -             | deactivated   | for `keep-alive` ,组件被除移的时候调用               |
| attached      | -             | 略                                                   |
| deattached    | -             | 略                                                   |
| beforeDestory | beforeDestory | 组件销毁之前调用                                     |
| destoryed     | destoryed     | 组件销毁后调用                                       |



#### 通过代码看表现

<pre>
```html
<!DOCTYPE html>
<html>
<head>
    <title></title>
    <script type="text/javascript" src="https://cdn.jsdelivr.net/vue/2.1.3/vue.js"></script>
</head>
<body>
<div id="app">
     <p>{{ message }}</p>
</div>
<script type="text/javascript">
  var app = new Vue({
      el: '#app',
      data: {
          message : "Hey, Developer" 
      },
       beforeCreate: function () {
                console.group('beforeCreate 创建前状态===============》');
               console.log("%c%s", "color:red" , "el     : " + this.$el); //undefined
               console.log("%c%s", "color:red","data   : " + this.$data); //undefined 
               console.log("%c%s", "color:red","message: " + this.message)  
        },
        created: function () {
            console.group('created 创建完毕状态===============》');
            console.log("%c%s", "color:red","el     : " + this.$el); //undefined
               console.log("%c%s", "color:red","data   : " + this.$data); //已被初始化 
               console.log("%c%s", "color:red","message: " + this.message); //已被初始化
        },
        beforeMount: function () {
            console.group('beforeMount 挂载前状态===============》');
            console.log("%c%s", "color:red","el     : " + (this.$el)); //已被初始化
            console.log(this.$el);
               console.log("%c%s", "color:red","data   : " + this.$data); //已被初始化  
               console.log("%c%s", "color:red","message: " + this.message); //已被初始化  
        },
        mounted: function () {
            console.group('mounted 挂载结束状态===============》');
            console.log("%c%s", "color:red","el     : " + this.$el); //已被初始化
            console.log(this.$el);    
               console.log("%c%s", "color:red","data   : " + this.$data); //已被初始化
               console.log("%c%s", "color:red","message: " + this.message); //已被初始化 
        },
        beforeUpdate: function () {
            console.group('beforeUpdate 更新前状态===============》');
            console.log("%c%s", "color:red","el     : " + this.$el);
            console.log(this.$el);   
               console.log("%c%s", "color:red","data   : " + this.$data); 
               console.log("%c%s", "color:red","message: " + this.message); 
        },
        updated: function () {
            console.group('updated 更新完成状态===============》');
            console.log("%c%s", "color:red","el     : " + this.$el);
            console.log(this.$el); 
               console.log("%c%s", "color:red","data   : " + this.$data); 
               console.log("%c%s", "color:red","message: " + this.message); 
        },
        beforeDestroy: function () {
            console.group('beforeDestroy 销毁前状态===============》');
            console.log("%c%s", "color:red","el     : " + this.$el);
            console.log(this.$el);    
               console.log("%c%s", "color:red","data   : " + this.$data); 
               console.log("%c%s", "color:red","message: " + this.message); 
        },
        destroyed: function () {
            console.group('destroyed 销毁完成状态===============》');
            console.log("%c%s", "color:red","el     : " + this.$el);
            console.log(this.$el);  
               console.log("%c%s", "color:red","data   : " + this.$data); 
               console.log("%c%s", "color:red","message: " + this.message)
        }
    })
</script>
</body>
</html>
```
</pre>

咱们在`chrome`浏览器里打开，`F12`看`console`就能发现

> 创建前/后： 在beforeCreated阶段，vue实例的挂载元素$el和数据对象data都为undefined，还未初始化。在created阶段，vue实例的数据对象data有了，$el还没有。
>
> 载入前/后：在beforeMount阶段，vue实例的$el和data都初始化了，但还是挂载之前为虚拟的dom节点，data.message还未替换。在mounted阶段，vue实例挂载完成，data.message成功渲染。
>
> 更新前/后：当data变化时，会触发beforeUpdate和updated方法。
>
> 销毁前/后：在执行destroy方法后，对data的改变不会再触发周期函数，说明此时vue实例已经解除了事件监听以及和dom的绑定，但是dom结构依然存在

![lifecycle-console](http://image.awebman.cn/pic2018071001.png)



###### Destory相关

销毁完成后，我们再重新改变message的值，vue不再对此动作进行响应了。但是原先生成的dom元素还存在，可以这么理解，执行了destroy操作，后续就不再受vue控制了。



---

#### Vue router钩子函数

##### 全局钩子

```javascript
const router = new VueRouter({...})
router.beforeEach((to, from, next) => {//do it})
router.afterEach(route => {//do it})
```

##### 某个路由独有的钩子

```javascript
const router = new VueRouter({
    routes: [
        {
            path: '/test',
            components: Test,
            beforeEnter: (to, from, next) => {//do it}
        }
    ]
})
```

##### 组件内部定义的钩子

```javascript
const Test = {
    template: `假设我就是组件内容`,
    beforeRouteEnter (to, from, next) {
        // 在渲染该组件的对应路由被 confirm 前调用
        // 不！能！获取组件实例 `this`
        // 因为当钩子执行前，组件实例还没被创建
    },
    beforeRouteUpdate (to, from, next) {
		// 在当前路由改变，但是该组件被复用时调用
        // 举例来说，对于一个带有动态参数的路径 /test/:id，在 /test/1 和 /test/2 之间跳转的时候，
        // 由于会渲染同样的 Foo 组件，因此组件实例会被复用。而这个钩子就会在这个情况下被调用。
        // 可以访问组件实例 `this`
	},
	beforeRouteLeave (to, from, next) {
        // 导航离开该组件的对应路由时调用
        // 可以访问组件实例 `this`
    }
}
```



## 生命周期总结

这么多钩子函数，我们怎么用呢，我的想法是：

Vue相关的

> `beforecreate` : 举个栗子：可以在这加个loading事件 
> `created` ：在这结束loading，还做一些初始化，实现函数自执行 
> `mounted` ： 在这发起后端请求，拿回数据，配合路由钩子做一些事情
> `beforeDestroy`： 你确认删除XX吗？ destroyed ：当前组件已被删除，清空相关内容



`beforeRouteEnter` 钩子 不能 访问 `this`，因为钩子在导航确认前被调用,因此即将登场的新组件还没被创建。

不过，你可以通过传一个回调给 `next`来访问组件实例。在导航被确认的时候执行回调，并且把组件实例作为回调方法的参数

>`beforeRouteEnter`
>
>`beforeRouteUpdate` (2.2 新增)
>
>`beforeRouteLeave`

__Yours sincerely AppleSun__