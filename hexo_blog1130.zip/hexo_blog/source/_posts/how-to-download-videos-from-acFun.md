---
title: how to download videos from acFun
date: 2018-07-02 20:54:36
tags: js
---

### How to download videos from Acfun

(原创,侵删)

作为一名A站死基佬，看到 有趣的视频的时候，第一时间想到的就是分享。然而 很多时候，我并不想直接分享A站源地址 出去，就想着 如果 我有这个 视频源地址 会不会更加的酷。

<!--more-->

工具准备:

​	Fiddler4 (version:v5.0.20181.14850 for .NET 4.6.1)

​	Chrome浏览器(最佳实践)



Here we go!!!

> STEP1：

​	打开目标视频页面,先别着急切换画质,打开fiddler.

> STEP2:

​	Fiddlers中remove all sessions,点选切换目标画质.等待页面重载,点击播放。

> STEP3:

​	Fiddlers 中 URL 一栏下 找到 /route_mp4? 的这一行，双击。

​	查看右侧的 Headers -> Raw 里面的location项, 你会看到 形如**http://video.acfun.cn/040040020400005ADE91F300010002900000000000-0000-0000-0205-042500000000.mp4?customer_id=5859fdaee4b0eaf5dd325b91&start=0.0&auth_key=1524593971-101027352552003e080c59f921874eec339bd615599frpcx12220p112p124p68d25553fb4d363-ACFUN-a28c15301e4543886878cf5e807beecd** 的地址,复制在浏览器中打开。

> STEP4:

​	看到一个video mp4的视频后,你会很兴奋的 右击下载,此时 Acfun会给你一个 大大的报错. **失败-已被禁止** 

​	Solution：右击视频--在新标签页中打开视频,在新的 标签页视频选择 视频另存为。

​	Tips: 如果在视频下载过程中出现下载终止，需要手动选择继续就好



昂, 就酱紫...

See U Next Time



**Yours sincerely AppleSun**